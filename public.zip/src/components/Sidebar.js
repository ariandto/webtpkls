import React, { useState } from 'react';
import { FaBars, FaTimes, FaHome, FaChartBar, FaLaptopCode, FaChartLine } from 'react-icons/fa';
import './Sidebar.css';

function App() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="app">
      <div className={`sidebar ${isOpen ? 'open' : 'collapsed'}`}>
        <div className="sidebar-header">
          <h3>{isOpen ? 'Transport Planning' : ''}</h3>
          <button className="sidebar-toggle" onClick={toggleSidebar}>
            {isOpen ? <FaTimes /> : <FaBars />}
          </button>
        </div>
        <div className="sidebar-title">
          {isOpen && <h4>Menu</h4>}
        </div>
        <ul className="sidebar-menu">
          <li>
            <a href="#" className="menu-item">
              <FaHome />
              {isOpen && <span className="menu-text">Home</span>}
              {!isOpen && (
                <span className="tooltip">
                  <span className="tooltip-icon"><FaHome /></span>
                  Home
                </span>
              )}
            </a>
          </li>
          <li>
            <a href="#" className="menu-item">
              <FaChartBar />
              {isOpen && <span className="menu-text">Dashboard</span>}
              {!isOpen && (
                <span className="tooltip">
                  <span className="tooltip-icon"><FaChartBar /></span>
                  Dashboard
                </span>
              )}
            </a>
          </li>
          <li>
            <a href="#" className="menu-item">
              <FaLaptopCode />
              {isOpen && <span className="menu-text">Report Delivery</span>}
              {!isOpen && (
                <span className="tooltip">
                  <span className="tooltip-icon"><FaLaptopCode /></span>
                  Report Delivery
                </span>
              )}
            </a>
          </li>
          <li>
            <a href="#" className="menu-item">
              <FaChartLine />
              {isOpen && <span className="menu-text">Reporting</span>}
              {!isOpen && (
                <span className="tooltip">
                  <span className="tooltip-icon"><FaChartLine /></span>
                  Reporting
                </span>
              )}
            </a>
          </li>
        </ul>
        <div className="profile-section">
          {isOpen && (
            <div className="profile-details">
              {/* <p className="profile-name">Your Name</p>
              <p className="profile-role">Your Role</p> */}
            </div>
          )}
        </div>
      </div>
      <div className="content">
        <h1>Main Content Area</h1>
        <p>This is the main content of your application.</p>
      </div>
    </div>
  );
}

export default App;
